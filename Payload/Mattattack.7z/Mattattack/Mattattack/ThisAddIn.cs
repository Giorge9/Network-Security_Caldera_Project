﻿using System;
using System.Net.Sockets;
using System.Threading.Tasks;
using Word = Microsoft.Office.Interop.Word;
using Office = Microsoft.Office.Core;
using Microsoft.Office.Tools.Word;
using System.Text;

namespace Mattattack
{
    public partial class ThisAddIn
    {
        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            // Esegui la scansione delle porte all'avvio dell'add-in
            Task.Run(() => ScanLocalhost());
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
        }

        private async Task ScanLocalhost()
        {
            const string localhost = "127.0.0.1";
            int startPort = 1; // Inizio della scansione delle porte
            int endPort = 1024; // Fine della scansione delle porte
            StringBuilder resultBuilder = new StringBuilder();

            for (int port = startPort; port <= endPort; port++)
            {
                using (TcpClient client = new TcpClient())
                {
                    try
                    {
                        // Tentativo di connessione al localhost sulla porta specificata
                        await client.ConnectAsync(localhost, port);
                        resultBuilder.AppendLine($"Port {port} is open.");
                    }
                    catch (SocketException)
                    {
                        resultBuilder.AppendLine($"Port {port} is closed.");
                    }
                }
            }

            // Output dei risultati nella console di debug (o puoi anche scrivere nel documento Word)
            System.Diagnostics.Debug.WriteLine(resultBuilder.ToString());
            System.Windows.Forms.MessageBox.Show(resultBuilder.ToString(), "Scan Results");
        }

        #region Codice generato da VSTO

        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }

        #endregion
    }
}
